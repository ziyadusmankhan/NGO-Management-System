<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();

            $table->string('name', 150);

            $table->string('slug', 150)->unique();

            $table->string('module', 100);

            $table->text('description')->nullable();

            $table->timestamps();

            $table->index('module');

            $table->unique([
                'name',
                'module',
            ]);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permissions');
    }
};